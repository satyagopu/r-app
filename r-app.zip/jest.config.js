// jest.config.js
module.exports = {
    // Add your Jest configuration options here
  };
  